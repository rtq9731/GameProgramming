#pragma once
#include <iostream>
#include <Windows.h>
#include <time.h>
#include <conio.h>
#include <stack>
#include "Console.h"
#include "Data.h"
#include "Player.h"

using namespace std;