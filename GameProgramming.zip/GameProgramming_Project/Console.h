#pragma once
#include "headers_WhatIneed.h"

extern void gotoXY(int x, int y);
extern void setTextColor(int color);
extern void clrscr();
extern void beep(int tone, int delay);
extern int getKeyDown();

